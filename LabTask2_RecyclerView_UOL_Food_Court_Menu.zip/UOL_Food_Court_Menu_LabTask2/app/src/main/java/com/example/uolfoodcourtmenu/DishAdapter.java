package com.example.uolfoodcourtmenu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DishAdapter extends RecyclerView.Adapter<DishAdapter.ViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    private final ArrayList<Dish> dishes;
    private final OnItemClickListener listener;

    public DishAdapter(ArrayList<Dish> dishes, OnItemClickListener listener) {
        this.dishes = dishes;
        this.listener = listener;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivDish;
        TextView tvName;
        TextView tvPrice;

        public ViewHolder(@NonNull View itemView, OnItemClickListener listener) {
            super(itemView);

            ivDish = itemView.findViewById(R.id.ivDish);
            tvName = itemView.findViewById(R.id.tvName);
            tvPrice = itemView.findViewById(R.id.tvPrice);

            itemView.setOnClickListener(v -> {
                int position = getBindingAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(position);
                }
            });
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_dish, parent, false);
        return new ViewHolder(view, listener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Dish dish = dishes.get(position);
        holder.ivDish.setImageResource(dish.getImageResId());
        holder.tvName.setText(dish.getName());
        holder.tvPrice.setText("Rs. " + dish.getPrice());
    }

    @Override
    public int getItemCount() {
        return dishes.size();
    }
}
