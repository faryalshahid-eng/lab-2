package com.example.uolfoodcourtmenu;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DishDetailActivity extends AppCompatActivity {

    private ImageView ivDetailDish;
    private TextView tvDetailName, tvDetailCategory,
            tvDetailPrice, tvDetailDescription;
    private Button btnCallOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dish_detail);

        ivDetailDish = findViewById(R.id.ivDetailDish);
        tvDetailName = findViewById(R.id.tvDetailName);
        tvDetailCategory = findViewById(R.id.tvDetailCategory);
        tvDetailPrice = findViewById(R.id.tvDetailPrice);
        tvDetailDescription = findViewById(R.id.tvDetailDescription);
        btnCallOrder = findViewById(R.id.btnCallOrder);

        String name = getIntent().getStringExtra(MainActivity.EXTRA_NAME);
        String category = getIntent().getStringExtra(MainActivity.EXTRA_CATEGORY);
        String description = getIntent().getStringExtra(MainActivity.EXTRA_DESCRIPTION);
        String phone = getIntent().getStringExtra(MainActivity.EXTRA_PHONE);
        int price = getIntent().getIntExtra(MainActivity.EXTRA_PRICE, 0);
        int imageId = getIntent().getIntExtra(MainActivity.EXTRA_IMAGE, 0);

        tvDetailName.setText(name);
        tvDetailCategory.setText("Category: " + category);
        tvDetailPrice.setText("Price: Rs. " + price);
        tvDetailDescription.setText(description);
        ivDetailDish.setImageResource(imageId);

        setTitle(name);

        btnCallOrder.setOnClickListener(v -> {
            Intent dialIntent = new Intent(
                    Intent.ACTION_DIAL,
                    Uri.parse("tel:" + phone)
            );

            try {
                startActivity(dialIntent);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(
                        DishDetailActivity.this,
                        "No dialer application found.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }
}
