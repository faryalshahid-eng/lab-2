package com.example.uolfoodcourtmenu;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
        implements DishAdapter.OnItemClickListener {

    public static final String EXTRA_NAME = "dish_name";
    public static final String EXTRA_CATEGORY = "dish_category";
    public static final String EXTRA_DESCRIPTION = "dish_description";
    public static final String EXTRA_PHONE = "dish_phone";
    public static final String EXTRA_PRICE = "dish_price";
    public static final String EXTRA_IMAGE = "dish_image";

    private final ArrayList<Dish> dishes = new ArrayList<>();
    private RecyclerView rvMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvMenu = findViewById(R.id.rvMenu);

        loadDishes();

        // Scenario 1: two-column grid.
        rvMenu.setLayoutManager(new GridLayoutManager(this, 2));
        rvMenu.setAdapter(new DishAdapter(dishes, this));
    }

    private void loadDishes() {
        dishes.add(new Dish(
                "Chicken Biryani", "Rice",
                "Spicy rice cooked with chicken and traditional spices.",
                "0300-1111111", 350, R.drawable.dish_biryani));

        dishes.add(new Dish(
                "Zinger Burger", "Fast Food",
                "Crispy chicken burger with fresh lettuce and sauce.",
                "0300-2222222", 450, R.drawable.dish_burger));

        dishes.add(new Dish(
                "Cheese Pizza", "Pizza",
                "Cheesy pizza topped with vegetables and herbs.",
                "0300-3333333", 550, R.drawable.dish_pizza));

        dishes.add(new Dish(
                "Creamy Pasta", "Pasta",
                "Creamy pasta prepared with a smooth white sauce.",
                "0300-4444444", 400, R.drawable.dish_pasta));

        dishes.add(new Dish(
                "Club Sandwich", "Sandwich",
                "Fresh layered sandwich with chicken, vegetables and sauce.",
                "0300-5555555", 380, R.drawable.dish_sandwich));

        dishes.add(new Dish(
                "Chicken Karahi", "Desi",
                "Chicken cooked in a rich tomato and spice-based karahi.",
                "0300-6666666", 700, R.drawable.dish_karahi));

        dishes.add(new Dish(
                "French Fries", "Snacks",
                "Crispy golden fries served as a quick snack.",
                "0300-7777777", 200, R.drawable.dish_fries));

        dishes.add(new Dish(
                "Doodh Patti Tea", "Drinks",
                "Traditional milk tea, served hot.",
                "0300-8888888", 120, R.drawable.dish_tea));
    }

    @Override
    public void onItemClick(int position) {
        Dish selectedDish = dishes.get(position);

        // Explicit Intent carrying only the tapped dish's data.
        Intent intent = new Intent(MainActivity.this, DishDetailActivity.class);
        intent.putExtra(EXTRA_NAME, selectedDish.getName());
        intent.putExtra(EXTRA_CATEGORY, selectedDish.getCategory());
        intent.putExtra(EXTRA_DESCRIPTION, selectedDish.getDescription());
        intent.putExtra(EXTRA_PHONE, selectedDish.getStallPhone());
        intent.putExtra(EXTRA_PRICE, selectedDish.getPrice());
        intent.putExtra(EXTRA_IMAGE, selectedDish.getImageResId());

        startActivity(intent);
    }
}
