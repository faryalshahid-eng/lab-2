# UOL Food Court Menu — Lab Task 02

This is a complete Java Android Studio implementation for the supplied Lab Task 02.

## Project
- RecyclerView + CardView
- Two-column GridLayoutManager
- 8 dishes
- Dish model class
- DishAdapter + static ViewHolder
- OnItemClickListener
- Explicit Intent with extras
- DishDetailActivity
- ACTION_DIAL with try/catch
- Vector drawable food images (no external image download required)

## Open
1. Extract the ZIP.
2. Open Android Studio.
3. Choose Open and select the `UOL_Food_Court_Menu` folder.
4. Let Gradle sync.
5. Run on an emulator/device.

## Required report evidence
You still need to run the app and capture:
1. Menu grid screenshot.
2. Details screen for dish 1.
3. Details screen for dish 2.
4. Details screen for dish 3.
5. Dialer screen after Call to Order.
6. Optional Toast screenshot if a dialer is unavailable.

## Important
The assignment asks for a public GitHub repository named:
`LabTask2_RecyclerView_<SAP ID>`

The package/application ID used here is:
`com.example.uolfoodcourtmenu`

If your Android Studio project already has a different package name, replace the package declaration/import paths consistently before running.
